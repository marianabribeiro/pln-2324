import json

file1 = open("jsons/trad.json", encoding="utf-8")
file2 = open("jsons/ministerio_scrapvf.json", encoding="utf-8")
file3 = open("jsons/DicOssos.json", encoding="utf-8")

json1 = json.load(file1)
json2 = json.load(file2)
json3 = json.load(file3)

docs={"Cardiologia":json1, "Ministerio Da Saude": json2, "Anatomia":json3}

file_out = open("jsons/json_compilado.json","w", encoding="utf-8")
json.dump(docs,file_out,ensure_ascii=False, indent=4)
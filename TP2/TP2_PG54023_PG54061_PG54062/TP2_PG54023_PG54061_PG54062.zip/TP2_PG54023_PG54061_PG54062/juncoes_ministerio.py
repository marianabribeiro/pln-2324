import json

file_1=open('jsons\ministerio1.json','r', encoding='utf-8')
json1=json.load(file_1)

file_2=open('jsons\ministerio2.json','r', encoding='utf-8')
json2=json.load(file_2)

file_3=open('jsons\ministerio3.json','r', encoding='utf-8')
json3=json.load(file_3)

# Inicializar o JSON combinado
json_combinado = {}
info_combinada={}
# Iterar sobre as chaves do primeiro JSON
for chave, valor in json3.items(): # categoria, descritores []
    if isinstance(valor, list):
        descritores_categoria={}
        for descritor in valor: # por cada descritor
                if descritor in json1.keys():
                    dic=json1[descritor]
                    descricao=dic["descricao"]
                   # print(descricao)
                    descritores_categoria[descritor]={"descricao":descricao, "assuntos":[]}

           

    if chave in json2.keys(): 
        descricao_categoria = json2[chave]
    else:
         descricao_categoria="Sem Informação"
    info_combinada[chave]={
                    "descrição categoria": descricao_categoria,
                    "descritores categoria": descritores_categoria
                    }
            
    json_combinado= info_combinada
    



# Imprimir o JSON combinado
file_out = open("jsons\ministerio_junto3.json", "w", encoding='utf-8')
json.dump(json_combinado, file_out, indent=4, ensure_ascii=False)  # guardar
file_out.close()
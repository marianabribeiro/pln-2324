
from bs4 import BeautifulSoup

import requests
import regex
import json
import string

import json

file_1=open('jsons\ministerio_junto.json','r', encoding='utf-8')
json1=json.load(file_1)



url_base="https://www.atlasdasaude.pt/search/node/"

for key in list(json1.keys()):
    print(len(json1.keys()))
    print(key)
    for key2 in json1[key]["descritores categoria"]:
       
        url=url_base+key2

        response=requests.get(url)
        print(url)
        html=response.text
        soup=BeautifulSoup(html, "html.parser")
        Lista=[]
        noticias=soup.find('ol', class_="search-results node-results")
        if noticias:
            blocos=noticias.find_all('a')
            print(blocos)
            for div in blocos:
                    texto=div.get_text()
                    link=div['href']

                    response2=requests.get(link)
                    
                    html2=response2.text
                    soup2=BeautifulSoup(html2, "html.parser")
                    
                    block_intro=soup2.find('div', class_="field field-name-field-intro")
                    if block_intro:
                        intro_text=block_intro.text
                        intro = intro_text[:300] + "..."
                    else:
                        intro = "Aceda ao link para mais informações..."
                         

                    lista=[texto, link, intro]
                    tuplo=tuple(lista)
                    Lista.append(tuplo)

            json1[key]["descritores categoria"][key2]["assuntos"]=Lista





file_out = open("jsons\ministerio_scrap.json", "w", encoding='utf-8')
json.dump(json1, file_out, indent=4, ensure_ascii=False)  # guardar
file_out.close()
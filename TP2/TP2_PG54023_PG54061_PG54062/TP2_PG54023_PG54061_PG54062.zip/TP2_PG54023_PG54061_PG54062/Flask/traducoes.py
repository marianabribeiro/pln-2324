from deep_translator import GoogleTranslator
import json
import re

file=open('jsons\card.json','r', encoding='utf-8')
conceitos=json.load(file)

conceitos['pt:es'] = {}
conceitos['pt:fr'] = {}

for designacao_pt in conceitos["pt:en"]:
    trad_es = GoogleTranslator(source='pt', target='es').translate(designacao_pt)
    trad_fr = GoogleTranslator(source='pt', target='fr').translate(designacao_pt)

    conceitos["pt:es"].update({designacao_pt:trad_es})
    conceitos["pt:fr"].update({designacao_pt:trad_fr})
    

file_out=open('jsons/trad.json','w',encoding='utf-8')
json.dump(conceitos,file_out,indent=4,ensure_ascii=False)


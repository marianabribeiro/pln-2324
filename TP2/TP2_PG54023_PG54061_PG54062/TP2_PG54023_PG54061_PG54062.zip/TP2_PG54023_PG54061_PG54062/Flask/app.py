from flask import Flask, render_template, request, redirect, url_for
import json
import re
import datetime
import urllib.parse
app = Flask(__name__)

file = open("jsons\json_compilado.json", encoding="utf-8")
json_all=json.load(file)
 
@app.route("/")
def home():
    return render_template("home.html")


@app.route("/ministerio/categorias")
def listar_categorias():
    categorias= json_all["Ministerio Da Saude"]
    return render_template("categorias.html",categorias=categorias)

@app.route("/ministerio/categorias/<cat>")
def consultar_categoria(cat):

    categorias= json_all["Ministerio Da Saude"]

    if cat in categorias:
        desc_cat=categorias[cat]["descrição categoria"]
        descritores=categorias[cat]["descritores categoria"]
        
        keys=list(descritores.keys())
        print(keys)
        return render_template("descricao.html",cat=cat, descritores=keys, descricao=desc_cat)
    else:
        return render_template("erro.html", erro="Categorias não existente na base de dados.")

@app.route("/ministerio/categorias/<cat>/<descritor>")
def consultar_descritor(cat, descritor):

    categorias= json_all["Ministerio Da Saude"]

    if cat in categorias:
        if descritor in categorias[cat]["descritores categoria"].keys():
            desc_descritor=categorias[cat]["descritores categoria"][descritor]["descricao"]
            noticias=categorias[cat]["descritores categoria"][descritor]["assuntos"]
            return render_template("descritor.html",cat=cat, descritor=descritor, descricao=desc_descritor, noticias=noticias)
        else:
            return render_template("erro.html", erro="Descritor não existente na base de dados.")
    else:
        return render_template("erro.html", erro="Categoria não existente na base de dados.")

def highlight_search_term(text, term):
    """Highlight the search term in the text."""
    highlighted = re.sub(f'({re.escape(term)})', r'<span class="highlight">\1</span>', text, flags=re.IGNORECASE)
    return highlighted

@app.route("/ministerio/noticias")
def listar_noticias():
    categorias = json_all["Ministerio Da Saude"]
    res = []
    for categoria in categorias:
        for descritor in categorias[categoria]["descritores categoria"].keys():
            for noticia in categorias[categoria]["descritores categoria"][descritor]["assuntos"]:
                res.append(noticia)
    
    
    search_query = request.args.get('search', '').lower()
    if search_query:
        res = [[highlight_search_term(noticia[0], search_query), noticia[1], highlight_search_term(noticia[2], search_query)] 
               for noticia in res if search_query in noticia[0].lower() or search_query in noticia[2].lower()]

    # Paginacao
    page = request.args.get('page', 1, type=int)
    per_page = 10
    total = len(res)
    total_pages = (total + per_page - 1) // per_page  # Calculate total pages
    
    start = (page - 1) * per_page
    end = start + per_page
    paginated_noticias = res[start:end]

    
    start_page = max(page - 2, 1)
    end_page = min(start_page + 4, total_pages)
    start_page = max(end_page - 4, 1)

    return render_template(
        "noticias.html", 
        noticias=paginated_noticias, 
        categorias=categorias, 
        page=page, 
        total_pages=total_pages, 
        start_page=start_page,
        end_page=end_page,
        per_page=per_page,
        search_query=search_query
    )


@app.route("/ministerio/noticias/<categoria>")
def listar_noticias_cat(categoria):
    categorias = json_all["Ministerio Da Saude"]
    res = []

    if categoria in categorias:
        for descritor in categorias[categoria]["descritores categoria"].keys():
            for noticia in categorias[categoria]["descritores categoria"][descritor]["assuntos"]:
                res.append(noticia)
    
    return render_template("noticias_cat.html", noticias=res, categorias=categorias)



def sanitize_title(title):
    sanitized = re.sub(r'[^A-Za-z0-9]+', '_', title)  # Substitui caracteres inválidos por underscores
    return sanitized

@app.route("/anatomia")
def consultar_temas_ossos():
    temas = json_all["Anatomia"]
    temas=list(temas.keys())
    return render_template("anatomia.html", temas=temas)

@app.route("/anatomia/<tema>")
def consultar_subtemas_ossos(tema):
    temas = json_all["Anatomia"]
    if tema in temas:
        subtemas= temas[tema]
        return render_template("anatomia_tema.html", subtemas=subtemas,tema=tema)
  
    

@app.route("/anatomia/<tema>/<subtema>")
def consultar_subsubtemas_ossos(tema,subtema):
    temas = json_all["Anatomia"]
    if tema in temas:
        if subtema in temas[tema]:
            subsubtema=temas[tema][subtema]
            intro=temas[tema][subtema]["Introdução:"]
            return render_template("anatomia_subtema.html", subt=subsubtema, subtema=subtema, tema=tema, intro=intro)

@app.route("/anatomia/<tema>/<subtema>/<subsub>")
def consultar_sub_sub_sub_temas_ossos(tema, subtema, subsub):
    temas = json_all["Anatomia"]
    if tema in temas and subtema in temas[tema]:
        subsubtemas = list(temas[tema][subtema].keys())
        if subsub in subsubtemas:
            current_index = subsubtemas.index(subsub)
            # Indice anterior
            if current_index - 1 >= 0:
                previous_index = current_index - 1
                previous_subsub = subsubtemas[previous_index]
            else:
                previous_index = None
                previous_subsub = None

            # Indice seguinte
            if current_index + 1 < (len(subsubtemas)-1):
                next_index = current_index + 1
                next_subsub = subsubtemas[next_index]
            else:
                next_index = None
                next_subsub = None

            sanitized_title = sanitize_title(subsub)
            print(sanitized_title)
            legenda = temas[tema][subtema][subsub]

            return render_template(
                "anatomia_legendas.html",
                legenda=legenda,
                subsub=subsub,
                subtema=subtema,
                tema=tema,
                image_filename=sanitized_title,
                previous_subsub=previous_subsub,
                next_subsub=next_subsub
            )
    
@app.route("/pesquisa_anatomia", methods=["GET"])
def pesquisar_termo_anatomia():
    search_term = request.args.get('search_term', '').lower()
    resultados = []

    if search_term:
        resultados = procurar_termo(json_all["Anatomia"], search_term)

    return render_template("pesquisa_ossos.html", search_term=search_term, resultados=resultados)

def procurar_termo(dicionario, termo, caminho=[]):
    resultados = []

    for key, value in dicionario.items():
        novo_caminho = caminho + [key]
        if isinstance(value, dict):
            resultados.extend(procurar_termo(value, termo, novo_caminho))
        elif termo in key.lower() or termo in str(value).lower():
            resultados.append((key, value, novo_caminho))

    return resultados

def construir_link(caminho):
    base_url = "http://127.0.0.1:5000/anatomia"
    partes_codificadas = [urllib.parse.quote(part) for part in caminho[:-1]]  # Excluir a última parte
    url_completa = base_url + '/' + '/'.join(partes_codificadas)
    return url_completa

app.jinja_env.filters['construir_link'] = construir_link


@app.route("/tradutor_cardiologia", methods=["GET", "POST"])
def listarConceitos():
    conceitos = json_all["Cardiologia"]
    dic_en_pt = conceitos["en:pt"]
    dic_pt_en = conceitos["pt:en"]
    dic_pt_es = conceitos["pt:es"]
    dic_pt_fr = conceitos["pt:fr"]
    
    if request.method == "POST":
        lang = request.form.get("lang", "en:pt")
    else:
        lang = "en:pt"
    
    return render_template("cardiologia.html", dic_en_pt=dic_en_pt, dic_pt_en=dic_pt_en, dic_pt_es=dic_pt_es,dic_pt_fr=dic_pt_fr,lang=lang)

@app.route("/adicionar_conceitos", methods=["POST"])
def adicionar_conceitos():
    conceitos = json_all["Cardiologia"]
    designacao = request.form.get("designacao")
    traducao = request.form.get("traducao")
    lang = request.form.get("lang")
    print(designacao)
    
    if designacao and traducao and lang:
        if lang == "PT:EN":
            conceitos["pt:en"][designacao] = traducao
        elif lang == "EN:PT":
            conceitos["en:pt"][designacao] = traducao
        elif lang == "PT:ES":
            conceitos["pt:es"][designacao] = traducao
        elif lang == "PT:FR":
            conceitos["pt:fr"][designacao] = traducao
        
        with open("jsons/json_compilado.json", "w", encoding="utf-8") as file:
            json.dump(json_all, file, ensure_ascii=False, indent=4)
        
        return redirect(url_for('listarConceitos'))
    else:
        return "Informações incompletas", 400

@app.route('/delete_entry', methods=['POST'])
def delete_entry():
    selected_entry = request.form.get('selected_entry')
    lang = request.form.get('lang', 'en:pt')
    conceitos = json_all["Cardiologia"]
    if selected_entry:
        backup_filename = f"jsons/backups/json_compilado_backup_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        with open(backup_filename, "w", encoding="utf-8") as backup_file:
            json.dump(json_all, backup_file, ensure_ascii=False, indent=4)

        if lang == 'en:pt':
            del conceitos["en:pt"][selected_entry]
        elif lang == 'pt:en':
            del conceitos["pt:en"][selected_entry]
        elif lang == 'pt:es':
            del conceitos["pt:es"][selected_entry]
        elif lang == 'pt:fr':
            del conceitos["pt:fr"][selected_entry]

        json_all["Cardiologia"] = conceitos

      
        with open("jsons/json_compilado.json", "w", encoding="utf-8") as file:
            json.dump(json_all, file, ensure_ascii=False, indent=4)

    return redirect(url_for('listarConceitos'))

if __name__ == "__main__":
    app.run(debug=True)